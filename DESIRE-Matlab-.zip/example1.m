% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 1                                                              %
%                                                                           %
%                                                                           %
% This is Figure 1 in Gabow and Myers (1978): a graph with 4 spanning trees %
%    rooted at vertex 1                                                     %
%                                                                           %
% RESULT: The graph has 4 spanning trees (ST) rooted at vertex (RV) 1 and   %
%    no spanning trees rooted at vertices 2-4.                              %
%                                                                           %
%         ST 1 RV 1   ST 2 RV 1   ST 3 RV 1   ST 4 RV 1                     %
%         1 -> 3      1 -> 3      1 -> 2      1 -> 2                        %
%         2 -> 4      1 -> 2      2 -> 4      2 -> 4                        %
%         3 -> 2      2 -> 4      4 -> 3      2 -> 3                        %
%                                                                           %
% Note: The spanning trees are AWAY from the root.                          %
%                                                                           %
% Reference: Gabow H and Meyers E (1978) Finding all spanning trees of      %
%    directed and undirected graphs. SIAM J Comput 7(3):280-287.            %
%    https://doi.org/10.1137/0207024                                        %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Number of vertices
V = 4;

% Initialize digraph
G = graph_(V);

% Digraph edges
G.addEdge(1, 2);
G.addEdge(1, 3);
G.addEdge(2, 3);
G.addEdge(2, 4);
G.addEdge(3, 2);
G.addEdge(4, 3);

% Root vertex where the spanning trees will come from
r = 1;

% Generate spanning tree rooted at vertex r
spanTree = directedSpanTreeAway(G, r);