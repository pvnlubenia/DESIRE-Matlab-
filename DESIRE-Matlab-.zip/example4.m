% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 4                                                              %
%                                                                           %
%                                                                           %
% This is Figure 1 in Gabow and Myers (1978)                                %
%                                                                           %
% RESULT: The graph has 0, 2, 4, and 2 spanning trees (ST) rooted at vertex %
%    (RV) 1, 2, 3, and4, respectively.                                      %
%                                                                           %
%         ST 1 RV 2   ST 1 RV 3   ST 1 RV 4                                 %
%         1 -> 3      1 -> 2      1 -> 3                                    %
%         3 -> 2      2 -> 4      2 -> 4                                    %
%         4 -> 3      4 -> 3      3 -> 2                                    %
%                                                                           %
%         ST 2 RV 2   ST 2 RV 3   ST 2 RV 4                                 %
%         1 -> 2      1 -> 3      1 -> 2                                    %
%         3 -> 2      2 -> 4      2 -> 4                                    %
%         4 -> 3      4 -> 3      3 -> 2                                    %
%                                                                           %
%                     ST 3 RV 3                                             %
%                     1 -> 2                                                %
%                     2 -> 3                                                %
%                     4 -> 3                                                %
%                                                                           %
%                     ST 4 RV 3                                             %
%                     1 -> 3                                                %
%                     2 -> 3                                                %
%                     4 -> 3                                                %
%                                                                           %
% Note: The spanning trees are TOWARDS the root.                            %
%                                                                           %
% Reference: Gabow H and Meyers E (1978) Finding all spanning trees of      %
%    and undirected graphs. SIAM J Comput 7(3):280-287.                     %
%    https://doi.org/10.1137/0207024                                        %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Number of vertices
V = 4;

% Initialize digraph
G = graph_(V);

% Digraph edges
G.addEdge(1, 2);
G.addEdge(1, 3);
G.addEdge(2, 3);
G.addEdge(2, 4);
G.addEdge(3, 2);
G.addEdge(4, 3);

% Root vertex where the spanning trees will come from
r = 1;

% Generate spanning tree rooted at vertex r
directedSpanTreeTowards(G, r);