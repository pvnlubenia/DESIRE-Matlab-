% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    Example 3                                                              %
%                                                                           %
%                                                                           %
% This is Figure 5 in Liu et al (2015): a graph that has no spanning tree   %
%                                                                           %
% RESULT: The graph has no spanning tree rooted at any vertex.              %
%                                                                           %
% Note: No spanning trees either away from or towards the root.             %
%                                                                           %
% Reference: Liu B, Lu W, Chen T (2015) Consensus in continuous-time        %
%    multiagent systems under discontinuous nonlinear protocols. IEEE Trans %
%    Neural Netw Learn Syst 26(2):290-301.                                  %
%    https://doi.org/10.1109/TNNLS.2014.2314699                             %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Number of vertices
V = 6;

% Initialize digraph
G = graph_(V);

% Digraph edges
G.addEdge(1, 2);
G.addEdge(1, 3);
G.addEdge(2, 1);
G.addEdge(2, 4);
G.addEdge(5, 3);
G.addEdge(5, 6);
G.addEdge(6, 4);
G.addEdge(6, 5);

% Root vertex where the spanning trees will come from
r = 1;

% Generate spanning tree rooted at vertex r
spanTree = directedSpanTreeAway(G, r);