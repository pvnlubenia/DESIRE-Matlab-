% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%    vertex                                                               %
%                                                                         %
%                                                                         %
% OUTPUT: Returns a vertex with default property values.                  %
%                                                                         %
% INPUT: None                                                             %
%                                                                         %
% Notes:                                                                  %
%    1. This class was converted from Python to Matlab.                   %
%    2. Python code can be found in https://github.com/ricelink/finding-  %
%          all-spanning-trees-in-directed-graph.                          %
%                                                                         %
% Reference: Gabow H and Meyers E (1978) Finding all spanning trees of    %
%    directed and undirected graphs. SIAM J Comput 7(3):280-287.          %
%    https://doi.org/10.1137/0207024                                      %
%                                                                         %
% Created: 21 June 2022                                                   %
% Last Modified: 18 July 2022                                             %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



classdef vertex

    % Properties of the vertex (with default values)
    properties
        d = 0      % Time of visit; Tracker of the order in which a vertex has been visited by the function depthFirstSearch under class graph_
        f = 0      % Time of visit; For the Bridge Test in function grow used in function directed_span_tree
        parent = 0 % Parent node of the vertex (actual value determined by the function depthFirstSearch under class graph_)
        visit = 1  % Visit status: 1 = not yet visited; 2 = currently visiting; 3 = visited
    end
end