% Number of vertices
V = 4;

% Initialize digraph
G = graph_(V);

% Digraph edges
G.addEdge(1, 2);
G.addEdge(1, 3);
G.addEdge(2, 3);
G.addEdge(2, 4);
G.addEdge(3, 2);
G.addEdge(4, 3);

% Initialize reversed edges
reverse_edge = cell(1, V);

% Reverse the edges
for i = 1:V
    for j = 1:length(G.edge{i})
        reverse_edge{G.edge{i}(j)}(end+1) = i;
    end
end

% Replace the edges of G
G.edge = reverse_edge;