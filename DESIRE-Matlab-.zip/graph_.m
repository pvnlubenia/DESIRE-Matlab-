% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%    graph_                                                               %
%                                                                         %
%                                                                         %
% OUTPUT: Returns a digraph with 'V' vertices and corresponding default   %
%    properties. The edges of the digraph are equally weighted.           %
%                                                                         %
% INPUT: V: number of vertices in the digraph                             %
%                                                                         %
% Notes:                                                                  %
%    1. This class was converted from Python to Matlab.                   %
%    2. Python code can be found in https://github.com/ricelink/finding-  %
%          all-spanning-trees-in-directed-graph.                          %
%    3. This class uses other classes: edge.m, vertex.m.                  %
%    4. This class has 8 functions inside it:                             %
%          - noKnownEdge                                                  %
%          - addEdge                                                      %
%          - removeEdge                                                   %
%          - connectedVertex                                              %
%          - connectedVertices                                            %
%          - depthFirstSearch                                             %
%          - displayGraph                                                 %
%          - plotGraph                                                    %
%                                                                         %
% Reference: Gabow H and Meyers E (1978) Finding all spanning trees of    %
%    directed and undirected graphs. SIAM J Comput 7(3):280-287.          %
%    https://doi.org/10.1137/0207024                                      %
%                                                                         %
% Created: 21 June 2022                                                   %
% Last Modified: 18 July 2022                                             %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% '< handle' allows our methods to operate on the same object 'self' rather than modifying a copy of the original object
classdef graph_ < handle

    % Properties of the graph (with default values)
    properties
        V = 1           % Number of vertices in the graph
        root_vertex = 1 % Root vertex
        edge            % Note: Default value created in function 'graph_'
        time = 0        % Time of visit; The order in which a vertex is visited by the depth first search algorithm
        vertex          % Note: Default value created in function 'graph_'
    end

    methods
        % Allows us to input the number of vertices 'V' in 'graph_'
        % In the succeeding methods, we call on the created graph using 'self'
        function self = graph_(V)

            % If you input a value inside 'graph_'
            if nargin > 0
                self.V = V;

                % Put placeholders in properties 'edge' and 'vertex'
                self.edge = repmat({[ ]}, 1, V);        % Default: list of V empty entries
                self.vertex = repmat({vertex()}, 1, V); % Default: list of V vertices

            % If you don't input anything inside 'create_graph'
            else
                self.edge = repmat({[ ]}, 1, 1);        % Default: list of 1 empty entry (since default is V = 1)
                self.vertex = repmat({vertex()}, 1, 1); % Default: list of 1 vertex (since default is V = 1)
            end
        end
    end










    % Functions used inside 'graph_'
    methods
        %
        % Function 1 of 8: noKnownEdge
        %    - Purpose: To check if the edge we are trying to add is NOT YET recorded
        %    - Output: Logical 1 if the edge is NOT YET in the property 'edge'; otherwise, the function returns 0
        %    - Input: The edge to be added using the 'edge' function with the vertex numbers
        %    - Note: If g = graph_(V), then execute this function using g.noKnownEdge(from_node, to_node)
        %
        function noKnownEdge_ = noKnownEdge(self, from_node, to_node)

            % Use 'edge' function to create an edge from vertex 'from_node' to vertex 'to_node'
            edge_ = edge(from_node, to_node);

            % In the 'from_node'th array (indicated in the edge we are trying to add) inside the property 'edge', go through each vertex number ('to_node') already recorded in the property
            for i = 1:length(self.edge{edge_.from_node})

                % If the edge is found, output 0 and end the function
                if self.edge{edge_.from_node}(i) == to_node
                    noKnownEdge_ = 0;
                    return % stops the function at the first instance the condition is satisfied
                end
            end

            % If, after going through all the 'to_node's, nothing is found, then output 1
            noKnownEdge_ = 1;
        end



        %
        % Function 2 of 8: addEdge
        %    - Purpose: To add an edge to the digraph
        %    - Output: Appends vertex number 'to_node' to the 'from_node'th array inside the property 'edge'
        %    - Input: Starting and ending vertex numbers (natural numbers) 'from_node' and 'to_node', respectively
        %    - Note: If g = graph_(V), then execute this function using g.addEdge(from_node, to_node)
        %
        function addEdge(self, from_node, to_node)

            % Use function 'noKnownEdge' to check if the edge is NOT YET in the property 'edge'
            if noKnownEdge(self, from_node, to_node) == 1

                % If the edge is not yet there, we add it
                self.edge{from_node} = [self.edge{from_node}, to_node];
            else

                % If the edge is already there, we display a message saying so
                disp(['Edge from vertex ', num2str(from_node), ' to vertex ', num2str(to_node), ' has already been added.'])
            end
        end



        %
        % Function 3 of 8: removeEdge
        %    - Purpose: To remove an edge from the digraph
        %    - Output: Removes vertex number 'to_node' from the 'from_node'th array inside the property 'edge'
        %    - Input: Starting and ending vertex numbers (natural numbers) 'from_node' and 'to_node', respectively
        %    - Note: If g = graph_(V), then execute this function using g.removeEdge(from_node, to_node)
        %
        function removeEdge(self, from_node, to_node)

            % Use function 'noKnownEdge' to check if the edge is NOT in the property 'edge'
            if noKnownEdge(self, from_node, to_node) == 1

                % If the edge is not yet there, then output 1
%                 removeEdge_ = 1;
                disp(['Edge from vertex ', num2str(from_node), ' to vertex ', num2str(to_node), ' is not in the graph.'])
            else

                % If the edge is there, we remove it from the property 'edge'
                self.edge{from_node}(self.edge{from_node} == to_node) = [ ];
            end
        end



        %
        % Function 4 of 8: connectedVertex
        %    - Purpose: To check if a vertex is a node of any edge
        %    - Output: Logical 1 if the vertex is a node in any edge; otherwise, the function returns 0
        %    - Input: Vertex number v
        %    - Note: If g = graph_(V), then execute this function using g.connectedVertex(v)
        %
        function connectedVertex_ = connectedVertex(self, v)

            % If vertex v is a starting node of any edge, return 1
            if ~isempty(self.edge{v})
                connectedVertex_ = 1;
                return % stops the function at the first instance the condition is satisfied
            end

            % Otherwise, go through each vertex
            for i = 1:length(self.edge)

                % Go through each vertex to which vertex i is connected to
                for j = 1:length(self.edge{i})
                    
                    % If vertex v is an ending node of any edge, return 1
                    if self.edge{i}(j) == v
                        connectedVertex_ = 1;
                        return % stops the function at the first instance the condition is satisfied
                    end
                end
            end

            % Return 0 if vertex v is not used in any edge
            connectedVertex_ = 0;
        end



        %
        % Function 5 of 8: connectedVertices
        %    - Purpose: To check how many vertices of the graph are connected (but does not indicated number of components)
        %    - Output: Number of connected vertices
        %    - Input: None
        %    - Note: If g = graph_(V), then execute this function using g.connectedVertices()
        %
        function connectedVertices_ = connectedVertices(self)
            
            % Initialize the number of connected vertices
            connectedVertices_ = 0;

            % Initialize checker if a vertex is connected to another one
            tally = zeros(1, self.V);

            % Go through each vertex
            for i = 1:self.V

                % Check if a vertex is a parent of another vertex
                if ~isempty(self.edge{i})
                    
                    % Add 1 to the vertex number of the checker
                    tally(i) = tally(i) + 1;
                end
            end

            % Go through each vertex
            for i = 1:length(self.edge)

                % Check to where each vertex is connected to (the children of the parents)
                for j = 1:length(self.edge{i})

                    % Add 1 to the vertex number of the checker
                    tally(self.edge{i}(j)) = tally(self.edge{i}(j)) + 1;
                end
            end

            % Go through each of the vertex checker
            for i = 1:self.V
                if tally(i) > 0

                    % Add 1 to the count of connected vertices for each nonzero tally
                    connectedVertices_ = connectedVertices_ + 1;
                end
            end
        end



        %
        % Function 6 of 8: depthFirstSearch
        %    - Purpose: To try to go through each vertex starting with vertex v, then determine its parent vertex
        %    - Output: The vertices in the property 'vertex' filled out with their corresponding properties after the depth first search algorithm
        %    - Input: Starting vertex for the search
        %    - Note: If g = graph_(V), then execute this function using g.depthFirstSearch(v)
        %
        function depthFirstSearch(self, v)
            
            % Set the visit status of vertex v to 2 to indicate that it is the current vertex being visited
            self.vertex{v}.visit = 2;

            % Add 1 to property 'time', the order in which a vertex is visited
            self.time = self.time + 1;

            % Input time of visit to the vertex
            self.vertex{v}.d = self.time;

            % Go to the vertices to which vertex v connects to
            for i = 1:length(self.edge{v})

                % If this connecting vertex is not yet visited
                if self.vertex{self.edge{v}(i)}.visit == 1

                    % v is its parent vertex
                    self.vertex{self.edge{v}(i)}.parent = v;

                    % Do the depth first search algorithm on this connecting vertex
                    self.depthFirstSearch(self.edge{v}(i));
                end
            end

            % Set the visit status of vertex v to 3 to indicate that the vertex is already visited
            self.vertex{v}.visit = 3;

            % Add 1 to property 'time'
            self.time = self.time + 1;

            % Used for the Bridge Test
            self.vertex{v}.f = self.time;
        end






        %
        % Function 7 of 8: displayGraph
        %    - Purpose: To display the edges of the graph
        %    - Output: A list of the edges of the graph
        %    - Input: None
        %    - Note: If g = graph_(V), then execute this function using g.displayGraph()
        %
        function displayGraph(self)

            % Go through each vertex
            for i = 1:self.V
                
                % If vertex i is connected to another vertex
                if ~isempty(self.edge{i})
                    
                    % Print each reaction i -> j
                    for j = 1:length(self.edge{i})
                        fprintf('  %d -> %d \n', [i, self.edge{i}(j)]);
                    end
                end
            end
        end



        %
        % Function 8 of 8: plotGraph
        %    - Purpose: To plot the graph
        %    - Output: A plot of the graph
        %    - Input: None
        %    - Note: If g = graph_(V), then execute this function using g.plotGraph()
        %
        function plotGraph(self)

            % Initialize a digraph g
            g = digraph();

            % Add edges to g
            % Go through each vertex
            for i = 1:self.V

                % Go through each element of the ith array in property 'edge'
                for j = 1:length(self.edge{i})

                    % Add the edge to g
                    g = addedge(g, i, self.edge{i}(j));
                end
            end

            % Plot the digraph
            plot(g);
        end
    end
end