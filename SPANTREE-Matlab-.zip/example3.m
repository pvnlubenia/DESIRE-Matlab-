% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 3                                                                %
%                                                                             %
%                                                                             %
% Subnetwork 1 of the insulin metabolic signaling network of Lubenia et al    %
%    (2022)                                                                   %
%                                                                             %
% RESULT: The graph has 2, 3, 22, 11, 4, 6, and 27 spanning trees rooted at   %
%            vertex 1, 2, 3, 4, 5, 6, and 7, respectively.                    %
%                                                                             %
% Reference: ﻿Lubenia P, Mendoza E, Lao A (2022) ﻿Reaction network analysis of  %
%    metabolic insulin signaling (submitted)                                  %
%    https://doi.org/10.48550/arXiv.2204.04614                                %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Number of vertices
V = 7;

% Initialize digraph
G = graph_(V);

% Digraph edges
G.addEdge(1, 5);
G.addEdge(2, 6);
G.addEdge(3, 4);
G.addEdge(3, 6);
G.addEdge(3, 7);
G.addEdge(4, 3);
G.addEdge(5, 1);
G.addEdge(5, 6);
G.addEdge(6, 2);
G.addEdge(6, 4);
G.addEdge(6, 5);
G.addEdge(7, 1);
G.addEdge(7, 2);
G.addEdge(7, 3);

% Root vertex where the spanning trees will come from
r = 7;

% Generate spanning tree rooted at vertex G.root_vertex
directed_span_tree(G, r)