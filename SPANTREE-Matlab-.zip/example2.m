% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 2                                                                %
%                                                                             %
%                                                                             %
% This is Figure 18 in Dutta et al (2020): 7-state model of conformational    %
%    changes that a ribosome can undergo during the elongation stage of       %
%    translation                                                              %
%                                                                             %
% RESULT: The graph has 1 spanning tree (ST) rooted at each vertex (RV)       %
%                                                                             %
%         ST 1 RV 1   ST 1 RV 2   ST 1 RV 3   ST 1 RV 4   ST 1 RV 5           %
%         1 -> 7      1 -> 7      1 -> 7      1 -> 7      1 -> 7              %
%         1 -> 3      2 -> 3      3 -> 6      3 -> 6      3 -> 6              %
%         3 -> 6      3 -> 6      3 -> 4      3 -> 2      3 -> 2              %
%         3 -> 4      3 -> 4      3 -> 2      3 -> 1      3 -> 1              %
%         3 -> 2      3 -> 1      3 -> 1      4 -> 5      4 -> 3              %
%         4 -> 5      4 -> 5      4 -> 5      4 -> 3      5 -> 4              %
%                                                                             %
%         ST 1 RV 6   ST 1 RV 7                                               %
%         1 -> 7      1 -> 3                                                  %
%         3 -> 4      3 -> 6                                                  %
%         3 -> 2      3 -> 4                                                  %
%         3 -> 1      3 -> 2                                                  %
%         4 -> 5      4 -> 5                                                  %
%         6 -> 3      7 -> 1                                                  %
%                                                                             %
% Reference: Dutta A, Schutz G, Chowdhury D (2020) Stochastic thermodynamics  %
%    and modes of operation of ribosome: A network theoretic perspective.     %
%    Phys Rev E 101(3):1-28. https://doi.org/10.1103/PhysRevE.101.032402      %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Number of vertices
V = 7;

% Initialize digraph
G = graph_(V);

% Digraph edges

G.addEdge(1, 3);
G.addEdge(1, 7);
G.addEdge(2, 3);
G.addEdge(3, 1);
G.addEdge(3, 2);
G.addEdge(3, 4);
G.addEdge(3, 6);
G.addEdge(4, 3);
G.addEdge(4, 5);
G.addEdge(5, 4);
G.addEdge(6, 3);
G.addEdge(7, 1);

% Root vertex where the spanning trees will come from
r = 1;

% Generate spanning tree rooted at vertex G.root_vertex
directed_span_tree(G, r);