% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 2                                                                %
%                                                                             %
%                                                                             %
% This is the generalized chemical reaction network (18) of the Histidine     %
%    Kinase Model in Johnston and Burton (2019)                               %
%                                                                             %
% RESULT: The graph has 1, 1, 2, and 1 spanning trees (ST) rooted at vertex   %
%            (RV) 1, 2, 3, and 4, respectively.                               %
%                                                                             %
%         ST 1 RV 1   ST 1 RV 2   ST 1 RV 3   ST 1 RV 4                       %
%         1 -> 2      2 -> 3      1 -> 2      1 -> 2                          %
%         2 -> 3      3 -> 4      3 -> 4      2 -> 3                          %
%         3 -> 4      4 -> 1      4 -> 1      4 -> 1                          %
%                                                                             %
%                                 ST 2 RV 3                                   %
%                                 3 -> 4                                      %
%                                 3 -> 2                                      %
%                                 4 -> 1                                      %
%                                                                             %
% Reference: Johnston M and Burton E (2019) Computing weakly reversible       %
%    deficiency zero network translations using elementary flux modes. Bull   %
%    Math Biol 81:1613-1644. https://doi.org/10.1007/s11538-019-00579-z       %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Number of vertices
V = 4;

% Initialize digraph
G = graph_(V);

% Digraph edges
G.addEdge(1, 2);
G.addEdge(2, 3);
G.addEdge(3, 2);
G.addEdge(3, 4);
G.addEdge(4, 1);

% Root vertex where the spanning trees will come from
r = 1;

% Generate spanning tree rooted at vertex G.root_vertex
directed_span_tree(G, r)